import fileinput, sys, os

oldText = input("Input the text you wish to be replaced: ")
newText = input("Input the text you wish to replace to: ")

oldText = " " + oldText + " "
newText = " " + newText + " "


def replaceAll(file, findexp, replaceexp):
    for line in fileinput.input(file, inplace=1):
        if findexp in line:
            line = line.replace(findexp, replaceexp)
        sys.stdout.write(line)

if __name__ == '__main__':
    files = os.listdir(os.getcwd())
    for file in files:
        newfile = os.path.join(os.getcwd(), file)
        replaceAll(newfile, oldText, newText)




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// This is the code for your desktop app.
// Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.

namespace DesktopApp7
{
    public partial class Form1 : Form
    {
        Point a, b, c, pivot;
        Random rand = new Random();
        int randPoint = 0;
        List<Point> points = new List<Point>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnRandom_Click(object sender, EventArgs e)
        {
            points.Clear();
            Invalidate();

            a = new Point(rand.Next(0, this.Width), rand.Next(0,this.Height));
            b = new Point(rand.Next(0, this.Width), rand.Next(0, this.Height));
            c = new Point(rand.Next(0, this.Width), rand.Next(0, this.Height));
            pivot = new Point(rand.Next(0, this.Width + 1), rand.Next(0, this.Height + 1));
            tmrDraw.Start();
            points.Add(a);
            points.Add(b);
            points.Add(c);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(typeof(string).Assembly.ImageRuntimeVersion);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Brush aBrush = (Brush)Brushes.Black;
            Brush bBrush = (Brush)Brushes.Red;

            Graphics g = this.CreateGraphics();
            g.FillRectangle(aBrush, a.X, a.Y, 1, 1);
            g.FillRectangle(aBrush, b.X, b.Y, 1, 1);
            g.FillRectangle(aBrush, c.X, c.Y, 1, 1);

            g.FillRectangle(bBrush, pivot.X, pivot.Y, 1, 1);

        }

        private void tmrDraw_Tick(object sender, EventArgs e)
        {

            Brush bBrush = null;
            for (int i = 0; i < 10000; i++)
            {
                randPoint = rand.Next(0, 3);
                if (randPoint == 0) //A
                {
                    pivot.X = (pivot.X + a.X) / 2;
                    pivot.Y = (pivot.Y + a.Y) / 2;
                    bBrush = (Brush)Brushes.Red;
                    points.Add(pivot);
                }
                if (randPoint == 1) //B
                {
                    pivot.X = (pivot.X + b.X) / 2;
                    pivot.Y = (pivot.Y + b.Y) / 2;
                    bBrush = (Brush)Brushes.Blue;
                    points.Add(pivot);

                }
                if (randPoint == 2) //C
                {
                    pivot.X = (pivot.X + c.X) / 2;
                    pivot.Y = (pivot.Y + c.Y) / 2;
                    bBrush = (Brush)Brushes.Green;
                    points.Add(pivot);
                }
                Graphics g = this.CreateGraphics();
                g.FillRectangle(bBrush, pivot.X, pivot.Y, 1, 1);
            }
        }
    }
}
